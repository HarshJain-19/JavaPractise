package problems.project2.model;

public enum EmployeeStatus {
    ACTIVE,
    INACTIVE,
    REGULAR,
    RESIGNED;
}

