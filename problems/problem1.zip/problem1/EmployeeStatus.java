package problems.problem1;

public enum EmployeeStatus {
    ACTIVE,
    INACTIVE,
    REGULAR,
    RESIGNED;
}

