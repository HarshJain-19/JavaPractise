package problems.problem1;

public enum Month {
    JANUARY("1",31),
    FEBRUARY("2",28),
    MARCH("3",31),
    APRIL("4",30),
    MAY("5",31),
    JUNE("6",30),
    JULY("7",31),
    AUGUST("8",31),
    SEPTEMBER("9",30),
    OCTOBER("10",31),
    NOVEMBER("11",30),
    DECEMBER("12",31);

    private int days;
    private String monthNumber;

    Month(String monthNumber, int days) {
        this.monthNumber = monthNumber;
        this.days = days;
    }

    public int getDays(boolean isLeapYear) {
        leapYear(isLeapYear);
        return this.days;
    }

    public String getMonthNumber() {
        return this.monthNumber;
    }

    public void leapYear(boolean isLeapYear) {
        if (this == FEBRUARY)
            this.days = isLeapYear ? 29 : 28;
    }

    public static Month getMonthByNumber(String monthNumber) {
        return switch (monthNumber) {
            case "1" -> Month.JANUARY;
            case "2" -> Month.FEBRUARY;
            case "3" -> Month.MARCH;
            case "4" -> Month.APRIL;
            case "5" -> Month.MAY;
            case "6" -> Month.JUNE;
            case "7" -> Month.JULY;
            case "8" -> Month.AUGUST;
            case "9" -> Month.SEPTEMBER;
            case "10" -> Month.OCTOBER;
            case "11" -> Month.NOVEMBER;
            case "12" -> Month.DECEMBER;
            default -> throw new IllegalArgumentException("Invalid month number: "+monthNumber);
        };
    }
}
